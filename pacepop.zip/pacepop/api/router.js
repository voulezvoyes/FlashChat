import QRCode from "qrcode";
import {
  ApiError,
  completeGift,
  createRoom,
  exportRoom,
  failGift,
  getRoom,
  joinRoom,
  normalizeCode,
  reserveGift,
  roomAction,
} from "../lib/rooms.mjs";
import { giftCatalog, issueGift, sodaStatus, validateEmail, validateGiftSelection } from "../lib/soda.mjs";
import { searchPlaces, walkingRoute } from "../lib/routes.mjs";

function pathSegments(req) {
  const fromQuery = req.query?.path;
  if (Array.isArray(fromQuery)) return fromQuery.map(decodeURIComponent);
  if (typeof fromQuery === "string") return fromQuery.split("/").filter(Boolean).map(decodeURIComponent);
  const pathname = new URL(req.url || "/", "http://localhost").pathname;
  return pathname.replace(/^\/api\//, "").split("/").filter(Boolean).map(decodeURIComponent);
}

function requestOrigin(req) {
  const configured = process.env.PUBLIC_ORIGIN || process.env.PACEPOP_PUBLIC_ORIGIN;
  if (configured) return configured.replace(/\/$/, "");
  const vercelHost = process.env.VERCEL_PROJECT_PRODUCTION_URL || process.env.VERCEL_URL;
  if (vercelHost) return `https://${vercelHost}`;
  const rawHost = String(req.headers?.["x-forwarded-host"] || req.headers?.host || "localhost:3000").split(",")[0].trim();
  const host = /^[a-zA-Z0-9.:[\]-]+$/.test(rawHost) ? rawHost : "localhost:3000";
  const forwardedProto = String(req.headers?.["x-forwarded-proto"] || "").split(",")[0].trim();
  const protocol = forwardedProto === "https" || (!host.startsWith("localhost") && !host.startsWith("127.0.0.1")) ? "https" : "http";
  return `${protocol}://${host}`;
}

async function body(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") {
    try { return JSON.parse(req.body); } catch { return {}; }
  }
  return {};
}

function viewerToken(req) {
  const header = req.headers?.authorization || "";
  if (header.startsWith("Bearer ")) return header.slice(7);
  return String(req.query?.participantToken || req.query?.pt || "");
}

function json(res, status, payload) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.end(JSON.stringify(payload));
}

function errorResponse(res, error) {
  const status = Number(error?.status || 500);
  const safeStatus = status >= 400 && status <= 599 ? status : 500;
  const code = error?.code || "internal_error";
  const message = error instanceof ApiError || safeStatus < 500 || typeof error?.code === "string"
    ? error.message
    : "잠시 문제가 생겼어요. 다시 시도해 주세요.";
  if (safeStatus >= 500) console.error("[pacepop]", error);
  json(res, safeStatus, { error: code, message });
}

export default async function handler(req, res) {
  try {
    const segments = pathSegments(req);
    const method = String(req.method || "GET").toUpperCase();
    const origin = requestOrigin(req);

    if (method === "GET" && segments[0] === "health") {
      return json(res, 200, { ok: true, soda: sodaStatus() });
    }

    if (method === "GET" && segments[0] === "qr" && segments[1]) {
      const code = normalizeCode(segments[1]);
      if (!code) throw new ApiError(400, "invalid_code", "방 코드를 확인해 주세요.");
      const svg = await QRCode.toString(`${origin}/j/${code}`, {
        type: "svg",
        errorCorrectionLevel: "M",
        margin: 1,
        color: { dark: "#080909", light: "#ffffff" },
      });
      res.statusCode = 200;
      res.setHeader("Content-Type", "image/svg+xml; charset=utf-8");
      res.setHeader("Cache-Control", "public, max-age=300");
      return res.end(svg);
    }

    if (method === "GET" && segments[0] === "soda" && segments[1] === "status") {
      return json(res, 200, sodaStatus());
    }

    if (method === "GET" && segments[0] === "soda" && segments[1] === "catalog") {
      return json(res, 200, await giftCatalog());
    }

    if (method === "GET" && segments[0] === "geo" && segments[1] === "search") {
      return json(res, 200, { results: await searchPlaces(req.query?.q) });
    }

    if (method === "POST" && segments[0] === "route") {
      const payload = await body(req);
      return json(res, 200, await walkingRoute(payload.start, payload.destination));
    }

    if (segments[0] !== "rooms") throw new ApiError(404, "not_found", "요청한 기능을 찾을 수 없어요.");

    if (method === "POST" && segments.length === 1) {
      return json(res, 201, await createRoom(await body(req), origin));
    }

    const code = normalizeCode(segments[1]);
    if (!code) throw new ApiError(400, "invalid_code", "방 코드를 확인해 주세요.");

    if (method === "GET" && segments.length === 2) {
      return json(res, 200, await getRoom(code, origin, viewerToken(req)));
    }

    if (method === "GET" && segments[2] === "export") {
      const exported = await exportRoom(code, viewerToken(req), String(req.query?.format || "json"));
      res.statusCode = 200;
      res.setHeader("Content-Type", exported.contentType);
      res.setHeader("Content-Disposition", `attachment; filename="${exported.filename}"`);
      res.setHeader("Cache-Control", "no-store");
      return res.end(exported.body);
    }

    if (method !== "POST") throw new ApiError(405, "method_not_allowed", "지원하지 않는 요청 방식이에요.");
    const payload = await body(req);

    if (segments[2] === "join") {
      return json(res, 200, await joinRoom(code, payload, origin));
    }

    if (segments[2] === "gift" && segments[3] === "claim") {
      const email = validateEmail(payload.email);
      const { product, catalog } = await validateGiftSelection(payload.productId);
      const reservation = await reserveGift(code, payload.participantToken, { email, product });
      if (reservation.idempotent) {
        return json(res, 200, { ok: true, idempotent: true, gift: reservation.gift });
      }
      try {
        const result = await issueGift({
          product,
          email,
          recipientName: reservation.participant.name,
          requestId: reservation.requestId,
        });
        const gift = await completeGift(code, reservation.requestId, result);
        return json(res, 200, { ok: true, live: catalog.live, sandbox: catalog.sandbox, gift });
      } catch (error) {
        await failGift(code, reservation.requestId, error.message).catch(() => {});
        throw error;
      }
    }

    if (!segments[2]) throw new ApiError(404, "not_found", "요청한 기능을 찾을 수 없어요.");
    return json(res, 200, await roomAction(code, segments[2], payload, origin));
  } catch (error) {
    return errorResponse(res, error);
  }
}
