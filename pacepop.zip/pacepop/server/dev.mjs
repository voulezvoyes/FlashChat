import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, join, normalize } from "node:path";

try { process.loadEnvFile?.(".env"); } catch {}
const { default: handler } = await import("../api/router.js");

const port = Number(process.env.PORT || 4173);
const host = process.env.HOST || "127.0.0.1";
const publicRoot = join(process.cwd(), "public");
const mime = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".avif": "image/avif",
  ".svg": "image/svg+xml",
};

async function parseBody(req) {
  if (!["POST", "PUT", "PATCH"].includes(req.method || "")) return undefined;
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 1_000_000) throw new Error("Request body too large");
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch { return {}; }
}

async function serveStatic(req, res, pathname) {
  const historyRoute = /^\/(j|host|w|coupon)\//.test(pathname);
  const requested = historyRoute || pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const safe = normalize(requested).replace(/^(\.\.(\/|\\|$))+/, "");
  const file = join(publicRoot, safe);
  if (!file.startsWith(publicRoot)) {
    res.statusCode = 403;
    return res.end("Forbidden");
  }
  try {
    const info = await stat(file);
    if (!info.isFile()) throw new Error("not file");
    const data = await readFile(file);
    res.statusCode = 200;
    res.setHeader("Content-Type", mime[extname(file).toLowerCase()] || "application/octet-stream");
    res.setHeader("Cache-Control", extname(file) === ".html" ? "no-store" : "public, max-age=60");
    return res.end(data);
  } catch {
    res.statusCode = 404;
    return res.end("Not found");
  }
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url || "/", `http://${req.headers.host || `${host}:${port}`}`);
    if (url.pathname.startsWith("/api/")) {
      req.query = Object.fromEntries(url.searchParams.entries());
      req.query.path = url.pathname.replace(/^\/api\//, "").split("/").filter(Boolean);
      req.body = await parseBody(req);
      return handler(req, res);
    }
    return serveStatic(req, res, url.pathname);
  } catch (error) {
    console.error(error);
    res.statusCode = 500;
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    return res.end(JSON.stringify({ error: "internal_error", message: "Local server error" }));
  }
});

server.listen(port, host, () => {
  console.log(`PacePop running at http://${host}:${port}`);
  if (!process.env.UPSTASH_REDIS_REST_URL && !process.env.KV_REST_API_URL) {
    console.log("Local durable file store active. Add Upstash Redis variables for Vercel multi-device persistence.");
  }
});
