# PacePop

기존 PacePop 디자인을 유지하면서 실제 방/러닝 기능을 연결한 Vercel용 모바일 웹앱입니다.

## 구현된 흐름

- 실제 장소 검색(OpenStreetMap), 보행 경로 계산(Valhalla), 코스별 거리·만날 시간·목표 페이스 설정
- 호스트 방 생성, 8자리 코드, QR/공유 링크, 카메라·사진 QR 스캔, 2~10명 정원
- 기기별 토큰 재입장과 중복 닉네임 처리
- 실제 GPS, 정확도/속도 스파이크 필터, 거리·페이스·진행률, 최대 300개 오프라인 fix 큐
- 1.4초 실시간 폴링, 연결 백오프, 화면 wake lock
- Green/Amber/Red SPREAD, HELP/Water/Rest/GiveUp, HELP 60초 에스컬레이션과 호스트 확인
- 채팅 속도 제한, KUDO 3개 제한·자기/중복 투표 방지
- 호스트 이양, 러너 내보내기, 위치가 비공개인 읽기 전용 관전 링크
- 종료 시 KUDO MVP 선정, 결과 화면, GPX/JSON/채팅 다운로드, 10분 후 자동 파기
- MVP 본인만 가능한 SodaGift 카탈로그 선택 및 이메일 발송
- PWA 셸 캐시와 Open Graph 공유 카드

## 로컬 실행

```bash
npm install
npm run dev
```

`http://127.0.0.1:4173`에서 열 수 있습니다. 로컬 방 데이터는 `.data/rooms`에 만료시간과 함께 저장됩니다. SodaGift 키가 없으면 발송 기능은 명확한 설정 오류를 반환하며 가짜 주문을 만들지 않습니다.

검증:

```bash
npm test
npm run build
node scripts/smoke.mjs
```

Smoke 검사는 실제 SodaGift Sandbox 카탈로그까지만 조회합니다. 실제 Sandbox 주문과 이메일 발송까지 검증할 때만 수신 가능한 주소를 지정합니다.

```bash
PACEPOP_SMOKE_GIFT=true PACEPOP_SMOKE_EMAIL=you@example.com node scripts/smoke.mjs
```

## Vercel 배포

이 폴더를 Vercel 프로젝트의 Root Directory로 지정합니다. `vercel.json`이 정적 앱, API Function, `/j`, `/host`, `/w`, `/coupon` 경로를 설정합니다.

Vercel에서는 아래 환경변수가 필수입니다. 누락되면 서버리스 인스턴스별 메모리 저장으로 가장하지 않고 `persistence_not_configured` 오류를 반환합니다.

```text
UPSTASH_REDIS_REST_URL
UPSTASH_REDIS_REST_TOKEN
```

Vercel Marketplace의 Upstash Redis integration이 `KV_REST_API_URL` / `KV_REST_API_TOKEN`을 제공하는 경우도 자동 지원합니다.

SodaGift Sandbox 발송에는 SafeCrew에서 사용한 키를 저장소 파일에 복사하지 말고 Vercel Project Settings → Environment Variables에 추가합니다.

```text
SODAGIFT_API_KEY
SODAGIFT_API_BASE=https://biz-sandbox-api.sodagift.com
SODAGIFT_COUNTRY=US
SODAGIFT_SENDER=PacePop
SODAGIFT_MAX_AMOUNT=20000
```

운영 발송으로 바꿀 때만 `SODAGIFT_API_BASE`를 운영 URL로 변경하세요. 실제 주문은 MVP가 상품과 이메일을 선택하고 마지막 버튼을 눌렀을 때만 생성됩니다.
