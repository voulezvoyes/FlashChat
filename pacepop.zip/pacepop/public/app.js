const app = document.getElementById("app");
const toast = document.getElementById("toast");
let activeLeafletMap = null;
let activeQrScanner = null;
let mapSequence = 0;

const state = {
  mode: "home",
  room: null,
  roomCode: "",
  participantToken: "",
  participantId: "",
  participantName: localStorage.getItem("pacepop.name") || "",
  pendingJoin: null,
  pollTimer: null,
  pollDelay: 1400,
  heartbeatTimer: null,
  watchId: null,
  latestFix: null,
  fixQueue: [],
  seq: Number(localStorage.getItem("pacepop.seq") || 0),
  connected: true,
  chatText: "",
  selectedGiftId: null,
  giftCatalog: null,
  courseDraft: null,
  hostTab: "live",
  runnerTab: "run",
  audioContext: null,
  wakeLock: null,
  seenAlerts: new Set(),
};

function tokenKey(code) {
  return `pacepop.token.${String(code || "").toUpperCase()}`;
}

function fixQueueKey(code) {
  return `pacepop.fixQueue.${String(code || "").toUpperCase()}`;
}

function readFixQueue(code) {
  try {
    const fixes = JSON.parse(localStorage.getItem(fixQueueKey(code)) || "[]");
    return Array.isArray(fixes) ? fixes.slice(-300) : [];
  } catch {
    return [];
  }
}

function readToken(code) {
  try { return localStorage.getItem(tokenKey(code)) || ""; } catch { return ""; }
}

function storeIdentity(data) {
  if (!data?.participantToken || !data?.code) return;
  state.participantToken = data.participantToken;
  state.participantId = data.participant?.id || data.meId || "";
  state.participantName = data.participant?.name || state.participantName;
  try {
    localStorage.setItem(tokenKey(data.code), data.participantToken);
    localStorage.setItem("pacepop.name", state.participantName);
  } catch {}
}

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[char]);
}

function attribute(value = "") {
  return escapeHtml(value).replace(/`/g, "&#096;");
}

async function api(path, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), options.timeout || 12_000);
  const token = options.token === undefined ? state.participantToken : options.token;
  const headers = { ...(options.headers || {}) };
  if (options.body !== undefined) headers["Content-Type"] = "application/json";
  if (token) headers.Authorization = `Bearer ${token}`;
  try {
    const response = await fetch(path, {
      ...options,
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      signal: controller.signal,
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.message || data.error || "요청을 처리하지 못했어요.");
      error.code = data.error;
      error.status = response.status;
      throw error;
    }
    return data;
  } catch (error) {
    if (error.name === "AbortError") throw new Error("네트워크 응답이 늦어요. 다시 시도해 주세요.");
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

function setApp(html, preserveScroll = true) {
  const previous = preserveScroll ? app.querySelector(".screen")?.scrollTop || 0 : 0;
  if (activeLeafletMap) {
    activeLeafletMap.remove();
    activeLeafletMap = null;
  }
  app.innerHTML = html;
  requestAnimationFrame(() => {
    const screen = app.querySelector(".screen");
    if (screen) screen.scrollTop = previous;
  });
}

function showToast(text, duration = 1800) {
  toast.textContent = text;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), duration);
}

function statusBar(light = false) {
  const time = new Intl.DateTimeFormat("ko-KR", { hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date());
  return `<div class="status" style="color:${light ? "#fff" : "#080808"}"><span>${time}</span><span class="device-status">${navigator.onLine ? "ONLINE" : "OFFLINE"}</span></div>`;
}

function icon(type) {
  const icons = {
    help: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"></circle><path d="M12 7v6"></path><path d="M12 17h.01"></path></svg>`,
    water: `<svg viewBox="0 0 24 24"><path d="M9 3h6l1 3v12a3 3 0 0 1-3 3h-2a3 3 0 0 1-3-3V6l1-3Z"></path><path d="M9 7h6"></path></svg>`,
    rest: `<svg viewBox="0 0 24 24"><path d="M5 19V5"></path><path d="M5 6h9l-1.5 3L14 12H5"></path></svg>`,
    giveup: `<svg viewBox="0 0 24 24"><path d="M6 20V4"></path><path d="M6 5h10v6H6"></path></svg>`,
  };
  return icons[type] || "";
}

function spreadColor(value) {
  return value === "red" ? "#ff4d50" : value === "amber" ? "#ffb11f" : "#2fd178";
}

function mountLeafletMap(id, room, currentId = "") {
  const element = document.getElementById(id);
  const L = window.L;
  if (!element || !L) return;
  const map = L.map(element, { zoomControl: false, attributionControl: true, preferCanvas: true });
  activeLeafletMap = map;
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; OpenStreetMap contributors",
  }).addTo(map);
  const bounds = [];
  const routeCoordinates = Array.isArray(room?.course?.coordinates) ? room.course.coordinates : [];
  if (routeCoordinates.length > 1) {
    L.polyline(routeCoordinates, { color: "#1d74f5", weight: 6, opacity: .86, lineCap: "round" }).addTo(map);
    bounds.push(...routeCoordinates);
  }
  if (room?.course?.start?.lat != null) {
    const start = [room.course.start.lat, room.course.start.lng];
    L.circleMarker(start, { radius: 7, color: "#fff", weight: 3, fillColor: "#1d74f5", fillOpacity: 1 }).bindTooltip("START").addTo(map);
    bounds.push(start);
  }
  if (room?.course?.destination?.lat != null) {
    const destination = [room.course.destination.lat, room.course.destination.lng];
    L.circleMarker(destination, { radius: 7, color: "#fff", weight: 3, fillColor: "#0c0c0c", fillOpacity: 1 }).bindTooltip("FINISH").addTo(map);
    bounds.push(destination);
  }
  for (const participant of room?.participants || []) {
    if (!Number.isFinite(Number(participant.lat)) || !Number.isFinite(Number(participant.lng))) continue;
    const mine = participant.id === currentId;
    const faded = ["offline", "gone"].includes(participant.connection);
    const icon = L.divIcon({
      className: "runner-map-marker",
      html: `<div class="map-avatar" style="border-color:${mine ? "#1d74f5" : spreadColor(participant.spread)};opacity:${faded ? ".52" : "1"}"><img src="${attribute(participant.avatar)}" alt=""><i style="background:${participant.connection === "online" ? participant.color : "#9ca1a7"}"></i></div><span>${mine ? "ME" : escapeHtml(participant.name)}</span>`,
      iconSize: [64, 64],
      iconAnchor: [32, 52],
    });
    const location = [Number(participant.lat), Number(participant.lng)];
    L.marker(location, { icon, keyboard: true, title: participant.name }).addTo(map);
    bounds.push(location);
  }
  if (bounds.length > 1) map.fitBounds(bounds, { padding: [32, 32], maxZoom: 17 });
  else if (bounds.length === 1) map.setView(bounds[0], 16);
  else map.setView([0, 0], 2);
  setTimeout(() => map.invalidateSize(), 0);
}

function renderMap(room, currentId = "") {
  const people = room?.participants || [];
  const note = room?.distribution?.active
    ? `${room.distribution.spreadM}m SPREAD`
    : `${people.length}/${room?.memberLimit || 10} RUNNERS`;
  const id = `liveMap${++mapSequence}`;
  requestAnimationFrame(() => mountLeafletMap(id, room, currentId));
  return `<section class="map real-map"><div id="${id}" class="leaflet-host" aria-label="실시간 러닝 지도"></div><span class="map-note">${escapeHtml(note)}</span></section>`;
}

function elapsed(startedAt, endedAt = null) {
  if (!startedAt) return "00:00";
  const seconds = Math.max(0, Math.floor(((endedAt || Date.now()) - startedAt) / 1000));
  const hours = Math.floor(seconds / 3600);
  const minutes = String(Math.floor((seconds % 3600) / 60)).padStart(2, "0");
  const rest = String(seconds % 60).padStart(2, "0");
  return hours ? `${hours}:${minutes}:${rest}` : `${minutes}:${rest}`;
}

function timeAgo(value) {
  const seconds = Math.max(0, Math.floor((Date.now() - Number(value || Date.now())) / 1000));
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  return `${Math.floor(seconds / 3600)}h`;
}

function renderConnectionBanner() {
  if (state.connected) return "";
  return `<div class="banner offline">연결을 다시 시도하고 있어요. 입력한 메시지와 위치는 기기에 잠시 보관됩니다.</div>`;
}

function notificationPrompt() {
  if (!("Notification" in window) || Notification.permission === "granted") return "";
  if (Notification.permission === "denied") return `<div class="banner">시스템 알림이 차단돼 있어요. 브라우저 사이트 설정에서 알림을 켜면 HELP를 놓치지 않아요.</div>`;
  return `<button class="mini-btn lime" onclick="enableSafetyNotifications()">안전 알림 켜기</button>`;
}

async function enableSafetyNotifications() {
  if (!("Notification" in window)) return showToast("이 브라우저는 시스템 알림을 지원하지 않아요.");
  const permission = await Notification.requestPermission();
  showToast(permission === "granted" ? "안전 알림을 켰어요." : "알림 권한이 허용되지 않았어요.", 2600);
  renderCurrent(true);
}

function renderHome() {
  stopRealtime();
  state.mode = "home";
  state.room = null;
  setApp(`${statusBar()}
    <section class="home">
      <div>
        <p class="eyebrow">QR ONE SCAN · TEMPORARY CREW</p>
        <h1>오늘 같이 뛸 사람,<br>한 번에 모여요.</h1>
      </div>
      <button class="role-card primary" onclick="openRunnerJoin()">
        <span><strong>I'M RUNNING</strong><span>QR을 스캔해서 크루에 합류해요</span></span>
        <b class="arrow">→</b>
      </button>
      <button class="role-card" onclick="openHostCreate()">
        <span><strong>I'M HOSTING</strong><span>코스를 만들고 QR을 뿌려요</span></span>
        <b class="arrow">→</b>
      </button>
      <p class="footnote">계정 없이 · 전화번호 없이 · 러닝 끝나면 자동 삭제</p>
    </section>`, false);
}

function defaultMeetTime() {
  const date = new Date(Date.now() + 10 * 60_000);
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

function newCourseDraft() {
  return {
    startQuery: "",
    destinationQuery: "",
    start: null,
    destination: null,
    route: null,
    searchTarget: null,
    results: [],
    busy: "",
    error: "",
    memberLimit: 8,
    targetPace: "6:00",
    meetAt: defaultMeetTime(),
    roomName: "",
    hostName: state.participantName || "Host",
  };
}

function paceMinutes(value) {
  const [minutes, seconds] = String(value || "6:00").split(":").map(Number);
  return Number(minutes || 0) + Number(seconds || 0) / 60;
}

function updateCourseDraft(field, value) {
  if (!state.courseDraft) return;
  state.courseDraft[field] = String(value || "").slice(0, 180);
  if (field === "startQuery") state.courseDraft.start = null;
  if (field === "destinationQuery") state.courseDraft.destination = null;
  if (["startQuery", "destinationQuery"].includes(field)) state.courseDraft.route = null;
}

function renderPlaceResults() {
  const draft = state.courseDraft;
  if (!draft?.searchTarget) return "";
  if (!draft.results.length) return `<div class="banner">검색 결과가 없어요. 건물명과 도시를 함께 입력해 보세요.</div>`;
  return `<div class="place-results">${draft.results.map((place, index) => `<button onclick="pickCoursePlace('${draft.searchTarget}',${index})"><strong>${escapeHtml(place.name)}</strong><span>${escapeHtml(place.label)}</span></button>`).join("")}</div>`;
}

function renderHostCreate(preserve = true) {
  const draft = state.courseDraft || (state.courseDraft = newCourseDraft());
  const route = draft.route;
  const estimate = route ? Math.max(1, Math.round(route.distanceKm * paceMinutes(draft.targetPace))) : 0;
  const courseRoom = route ? { course: { ...route, targetPace: draft.targetPace }, participants: [], memberLimit: draft.memberLimit, distribution: {} } : null;
  setApp(`${statusBar(true)}
    <section class="screen dark-screen setup-screen">
      <div class="topbar"><button class="icon-btn" onclick="goHome()" aria-label="홈으로">‹</button><span class="pill">HOST</span></div>
      <div class="stack">
        <div><h2 class="title">어디서 어디까지<br>달릴까요?</h2><p class="sub" style="margin-top:9px">장소를 검색하면 실제 보행 경로와 거리를 계산합니다.</p></div>
        <div class="setup-route">
          <div class="route-field route-input"><span class="marker"></span><label><small>START</small><input id="startQuery" value="${attribute(draft.startQuery)}" placeholder="출발 장소 검색" oninput="updateCourseDraft('startQuery',this.value)" onkeydown="if(event.key==='Enter') searchCoursePlace('start')"></label><button onclick="searchCoursePlace('start')">검색</button></div>
          <button class="current-location" onclick="useCurrentCourseStart()">◎ 현재 위치를 출발지로 사용</button>
          <div class="route-field route-input"><span class="marker"></span><label><small>FINISH</small><input id="destinationQuery" value="${attribute(draft.destinationQuery)}" placeholder="도착 장소 검색" oninput="updateCourseDraft('destinationQuery',this.value)" onkeydown="if(event.key==='Enter') searchCoursePlace('destination')"></label><button onclick="searchCoursePlace('destination')">검색</button></div>
        </div>
        ${draft.busy ? `<div class="banner">${escapeHtml(draft.busy)}</div>` : ""}
        ${draft.error ? `<div class="banner urgent">${escapeHtml(draft.error)}</div>` : ""}
        ${renderPlaceResults()}
        ${route ? `${renderMap(courseRoom)}<div class="route-stats"><div><small>DISTANCE</small><b>${route.distanceKm.toFixed(2)} KM</b></div><div><small>EST. TIME</small><b>${estimate} MIN</b></div><div><small>MEET AT</small><b>${escapeHtml(draft.meetAt)}</b></div></div>` : ""}
        <div class="panel stack">
          <label class="field-label">호스트 이름<input id="hostName" maxlength="12" autocomplete="name" value="${attribute(draft.hostName)}" oninput="updateCourseDraft('hostName',this.value)"></label>
          <label class="field-label">방 이름<input id="roomName" maxlength="30" value="${attribute(draft.roomName)}" placeholder="경로를 선택하면 자동으로 만들어요" oninput="updateCourseDraft('roomName',this.value)"></label>
          <label class="field-label">만날 시간<input type="time" value="${attribute(draft.meetAt)}" onchange="setMeetAt(this.value)"></label>
          <div><span class="field-label">목표 페이스</span><div class="pace-options">${["4:30", "5:00", "5:30", "6:00", "6:30", "7:00", "8:00"].map((pace) => `<button class="${draft.targetPace === pace ? "selected" : ""}" onclick="setTargetPace('${pace}')">${pace}</button>`).join("")}</div></div>
          <div class="crew-limit"><span><small>CREW LIMIT</small><strong>호스트 포함 최대 인원</strong></span><span><button onclick="changeMemberLimit(-1)">−</button><b>${draft.memberLimit}</b><button onclick="changeMemberLimit(1)">+</button></span></div>
          <button class="cta" onclick="createHostRoom()" ${route ? "" : "disabled"}>CREATE RUN &amp; GET QR</button>
        </div>
        <p class="sub" style="text-align:center">장소 검색 © OpenStreetMap contributors · 보행 경로 Valhalla</p>
      </div>
    </section>`, preserve);
}

function openHostCreate() {
  ensureAudio();
  state.mode = "create";
  state.courseDraft = newCourseDraft();
  renderHostCreate(false);
}

async function searchCoursePlace(target) {
  const draft = state.courseDraft;
  const input = document.getElementById(target === "start" ? "startQuery" : "destinationQuery");
  const query = input?.value.trim() || "";
  updateCourseDraft(target === "start" ? "startQuery" : "destinationQuery", query);
  if (query.length < 2) return showToast("장소 이름을 두 글자 이상 입력해 주세요.");
  draft.busy = "장소를 검색하고 있어요…";
  draft.error = "";
  draft.results = [];
  draft.searchTarget = target;
  renderHostCreate(true);
  try {
    const data = await api(`/api/geo/search?q=${encodeURIComponent(query)}`, { token: "" });
    draft.results = data.results || [];
  } catch (error) {
    draft.error = error.message;
  } finally {
    draft.busy = "";
    renderHostCreate(true);
  }
}

async function pickCoursePlace(target, index) {
  const draft = state.courseDraft;
  const place = draft?.results?.[index];
  if (!place) return;
  draft[target] = place;
  draft[`${target}Query`] = place.label;
  draft.results = [];
  draft.searchTarget = null;
  draft.error = "";
  if (draft.start && draft.destination) await calculateCourseRoute();
  else renderHostCreate(false);
}

async function useCurrentCourseStart() {
  const draft = state.courseDraft;
  draft.busy = "현재 위치를 찾고 있어요…";
  draft.error = "";
  renderHostCreate(true);
  try {
    const fix = await requestInitialPosition();
    draft.start = { id: "current", name: "현재 위치", label: "내 현재 위치", lat: fix.lat, lng: fix.lng };
    draft.startQuery = "내 현재 위치";
    if (draft.destination) await calculateCourseRoute();
  } catch (error) {
    draft.error = error.message;
  } finally {
    draft.busy = "";
    if (!draft.route) renderHostCreate(false);
  }
}

async function calculateCourseRoute() {
  const draft = state.courseDraft;
  if (!draft?.start || !draft?.destination) return;
  draft.busy = "실제 보행 경로를 계산하고 있어요…";
  draft.error = "";
  draft.route = null;
  renderHostCreate(true);
  try {
    draft.route = await api("/api/route", { method: "POST", token: "", body: { start: draft.start, destination: draft.destination } });
    draft.roomName ||= `${draft.start.name} → ${draft.destination.name}`.slice(0, 30);
  } catch (error) {
    draft.error = error.message;
  } finally {
    draft.busy = "";
    renderHostCreate(false);
  }
}

function setTargetPace(pace) {
  state.courseDraft.targetPace = pace;
  renderHostCreate(true);
}

function setMeetAt(value) {
  state.courseDraft.meetAt = value;
  renderHostCreate(true);
}

function changeMemberLimit(delta) {
  state.courseDraft.memberLimit = Math.max(2, Math.min(10, state.courseDraft.memberLimit + Number(delta || 0)));
  renderHostCreate(true);
}

async function createHostRoom() {
  const button = document.activeElement?.tagName === "BUTTON" ? document.activeElement : null;
  if (button) button.disabled = true;
  try {
    const draft = state.courseDraft;
    if (!draft?.route) throw new Error("출발지와 도착지를 선택해 실제 경로를 먼저 만들어 주세요.");
    const hostName = document.getElementById("hostName")?.value.trim() || draft.hostName || "Host";
    const name = document.getElementById("roomName")?.value.trim() || draft.roomName;
    const room = await api("/api/rooms", { method: "POST", body: {
      hostName,
      name,
      memberLimit: draft.memberLimit,
      course: { ...draft.route, targetPace: draft.targetPace, meetAt: draft.meetAt },
    }, token: "" });
    storeIdentity(room);
    state.room = room;
    state.roomCode = room.code;
    state.fixQueue = readFixQueue(room.code);
    state.mode = "host";
    history.replaceState(null, "", `/host/${room.code}`);
    renderHost(false);
    startPolling();
    startHeartbeat();
  } catch (error) {
    showToast(error.message, 2600);
    if (button) button.disabled = false;
  }
}

function openRunnerJoin() {
  ensureAudio();
  state.mode = "join";
  renderJoin(false);
}

function renderJoin(preserve = true) {
  const room = state.room;
  setApp(`${statusBar()}
    <section class="screen dark-screen join-screen">
      <div class="topbar">
        <button class="icon-btn" onclick="goHome()" aria-label="홈으로">‹</button>
        <span class="pill">RUNNER</span>
      </div>
      <div class="stack">
        <div>
          <p class="report-kicker">JOIN · 1 / 2</p>
          <h2 class="title" style="margin-top:12px">크루에 합류할<br>준비가 됐나요?</h2>
          <p class="sub" style="margin-top:9px">${room ? `${escapeHtml(room.name)} · ${room.participants.length}/${room.memberLimit}명` : "QR로 들어왔다면 코드가 자동으로 채워져요."}</p>
        </div>
        ${room?.phase === "ended" ? `<div class="banner urgent">이미 끝난 러닝이에요.</div>` : ""}
        <div class="panel stack">
          <label class="field-label">내 이름<input id="joinName" maxlength="12" autocomplete="name" value="${attribute(state.participantName)}" placeholder="Runner"></label>
          <label class="field-label">방 코드<input id="joinCode" maxlength="8" autocomplete="off" value="${attribute(state.roomCode)}" placeholder="ROOM CODE" style="text-transform:uppercase"></label>
          <button class="ghost qr-scan-button" onclick="openQrScanner()">카메라로 QR 스캔</button>
          <div class="banner">입장할 때 위치 권한을 한 번 요청합니다. 위치는 이 임시방 안에서만 공유되고 종료 10분 뒤 삭제돼요.</div>
          <button class="cta" onclick="joinRoom()" ${room?.phase === "ended" ? "disabled" : ""}>JOIN THE RUN</button>
        </div>
      </div>
    </section>`, preserve);
}

function qrRoomCode(value) {
  const raw = String(value?.data || value || "").trim();
  try {
    const url = new URL(raw, location.origin);
    const match = url.pathname.match(/^\/j\/([A-Za-z0-9]{1,8})/);
    if (match) return match[1].toUpperCase();
  } catch {}
  const normalized = raw.toUpperCase().replace(/[^A-Z0-9]/g, "");
  return normalized.length === 8 ? normalized : "";
}

async function acceptScannedQr(result) {
  const code = qrRoomCode(result);
  if (!code) return showToast("PacePop 입장 QR이 아니에요.", 2600);
  closeModal();
  state.roomCode = code;
  history.replaceState(null, "", `/j/${code}`);
  await loadRoom(code, "join");
}

async function openQrScanner() {
  state.participantName = document.getElementById("joinName")?.value.trim() || state.participantName;
  closeModal();
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.id = "modal";
  overlay.innerHTML = `<div class="modal-card scanner-modal stack" role="dialog" aria-modal="true" aria-label="QR 스캐너">
    <div class="phase-row" style="justify-content:space-between"><div><p class="report-kicker">PACEPOP QR</p><h2 class="title" style="font-size:28px;margin-top:8px">입장 QR을 비춰주세요</h2></div><button class="icon-btn" onclick="closeModal()" aria-label="닫기">×</button></div>
    <div class="scanner-frame"><video id="qrVideo" playsinline muted></video><span></span></div>
    <label class="ghost file-scan">사진에서 QR 찾기<input type="file" accept="image/*" capture="environment" onchange="scanQrFile(this)"></label>
    <div id="scannerStatus" class="banner">카메라 권한을 허용하면 자동으로 인식합니다.</div>
  </div>`;
  document.body.appendChild(overlay);
  try {
    const { default: QrScanner } = await import("/vendor/qr-scanner.min.js");
    const video = document.getElementById("qrVideo");
    if (!video) return;
    activeQrScanner = new QrScanner(video, (result) => acceptScannedQr(result), {
      preferredCamera: "environment",
      highlightScanRegion: true,
      highlightCodeOutline: true,
      returnDetailedScanResult: true,
    });
    await activeQrScanner.start();
    const status = document.getElementById("scannerStatus");
    if (status) status.textContent = "QR을 찾고 있어요…";
  } catch (error) {
    const status = document.getElementById("scannerStatus");
    if (status) {
      status.classList.add("urgent");
      status.textContent = error?.name === "NotAllowedError" ? "카메라 권한이 꺼져 있어요. 권한을 켜거나 사진을 선택해 주세요." : "카메라를 열지 못했어요. QR 사진을 선택해 주세요.";
    }
  }
}

async function scanQrFile(input) {
  const file = input?.files?.[0];
  if (!file) return;
  try {
    const { default: QrScanner } = await import("/vendor/qr-scanner.min.js");
    await acceptScannedQr(await QrScanner.scanImage(file, { returnDetailedScanResult: true }));
  } catch {
    showToast("사진에서 QR을 찾지 못했어요.", 2600);
  }
}

function requestInitialPosition() {
  return new Promise((resolve, reject) => {
    if (!window.isSecureContext || !("geolocation" in navigator)) {
      reject(new Error(window.isSecureContext ? "이 브라우저는 위치를 지원하지 않아요." : "GPS는 HTTPS 연결에서 사용할 수 있어요."));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => resolve({
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: position.timestamp,
      }),
      (error) => reject(new Error(error.code === 1 ? "위치 권한이 꺼져 있어요." : "현재 위치를 찾지 못했어요.")),
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 15_000 },
    );
  });
}

async function joinRoom() {
  ensureAudio();
  const name = document.getElementById("joinName")?.value.trim() || "Runner";
  const code = (document.getElementById("joinCode")?.value || "").trim().toUpperCase();
  if (!code) return showToast("방 코드를 입력해 주세요.");
  state.pendingJoin = { name, code };
  const button = document.activeElement?.tagName === "BUTTON" ? document.activeElement : null;
  if (button) {
    button.disabled = true;
    button.textContent = "GPS 찾는 중…";
  }
  try {
    const fix = await requestInitialPosition();
    await completeJoin(fix);
  } catch (error) {
    showLocationFallback(error.message);
    if (button) {
      button.disabled = false;
      button.textContent = "위치 허용하고 입장하기";
    }
  }
}

function showLocationFallback(message) {
  closeModal();
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.id = "modal";
  overlay.innerHTML = `<div class="modal-card stack" role="dialog" aria-modal="true" aria-label="위치 권한 필요">
    <div><h2 class="title" style="font-size:28px">위치가 필요해요</h2><p class="sub" style="margin-top:8px">${escapeHtml(message)}</p></div>
    <div class="banner">브라우저 설정에서 이 사이트의 위치 권한을 켠 뒤 다시 시도해 주세요. 실제 거리와 페이스 측정을 위해 위치 없이 입장할 수는 없어요.</div>
    <button class="cta" onclick="retryLocationJoin()">위치 다시 시도</button>
    <button class="mini-btn" onclick="closeModal()">취소</button>
  </div>`;
  document.body.appendChild(overlay);
}

async function retryLocationJoin() {
  try {
    const fix = await requestInitialPosition();
    closeModal();
    await completeJoin(fix);
  } catch (error) {
    showToast(error.message, 2600);
  }
}

async function completeJoin(fix) {
  const { name, code } = state.pendingJoin || {};
  if (!code) return;
  try {
    const existingToken = readToken(code);
    const room = await api(`/api/rooms/${code}/join`, {
      method: "POST",
      token: existingToken,
      body: { name, participantToken: existingToken || undefined },
    });
    storeIdentity(room);
    state.room = room;
    state.roomCode = room.code;
    state.fixQueue = readFixQueue(room.code);
    state.mode = room.viewerRole === "host" ? "host" : "runner";
    state.latestFix = fix;
    history.replaceState(null, "", room.viewerRole === "host" ? `/host/${room.code}` : `/j/${room.code}`);
    if (room.viewerRole === "host") renderHost(false);
    else renderRunner(false);
    startPolling();
    startLocation();
    startHeartbeat();
    requestWakeLock();
    heartbeat();
  } catch (error) {
    showToast(error.message, 2800);
  }
}

function renderMessages(room, limit = 8) {
  const messages = (room.messages || []).slice(-limit).reverse();
  return messages.map((message) => `<div class="message">
    <div class="mini-avatar" style="display:grid;place-items:center;background:${message.kind === "water" ? "#e7f1ff" : message.kind === "rest" ? "#f3ffd1" : message.kind === "help" ? "#ffe5e7" : "#fff"}">${message.kind === "water" ? "W" : message.kind === "rest" ? "R" : message.kind === "help" ? "!" : "·"}</div>
    <div><strong>${escapeHtml(message.name)}</strong><span>${escapeHtml(message.text)}</span></div>
    <span class="sub">${timeAgo(message.createdAt)}</span>
  </div>`).join("") || `<p class="sub">메시지가 아직 없어요.</p>`;
}

function personCard(participant, hostControls = false) {
  const room = state.room || {};
  const mine = participant.id === room.meId;
  const alreadySent = (room.kudoVotes || []).some((vote) => vote.fromId === room.meId && vote.toId === participant.id);
  const canKudo = !mine && participant.role !== "host" && !alreadySent && room.kudoRemaining > 0 && room.phase !== "ended";
  const count = room.phase === "ended" ? ` · KUDO ${participant.kudos || 0}` : "";
  const status = participant.intent === "gave_up" ? "GAVE UP" : String(participant.status || "running").toUpperCase();
  const controls = hostControls && !mine && participant.role !== "host"
    ? `<div class="host-actions"><button class="mini-btn lime" onclick="sendKudo('${participant.id}')" ${canKudo ? "" : "disabled"}>${alreadySent ? "✓" : "KUDO"}</button><button class="mini-btn" onclick="transferHost('${participant.id}')">HOST</button><button class="mini-btn danger" onclick="kickRunner('${participant.id}')">OUT</button></div>`
    : canKudo
      ? `<button class="kudo" onclick="sendKudo('${participant.id}')">KUDO</button>`
      : `<button class="kudo" disabled>${alreadySent ? "✓ SENT" : participant.role === "host" ? "HOST" : room.kudoRemaining ? "KUDO" : "0 LEFT"}</button>`;
  return `<div class="person">
    <div class="mini-avatar" style="border-color:${spreadColor(participant.spread)}"><img src="${attribute(participant.avatar)}" alt=""></div>
    <div><strong>${escapeHtml(participant.name)}</strong><span><i class="connection-dot ${attribute(participant.connection)}"></i>${Number(participant.distance || 0).toFixed(2)} km · ${escapeHtml(participant.pace || "--")} · ${status}${count}</span></div>
    ${controls}
  </div>`;
}

function renderSpread(room) {
  const distribution = room.distribution || { green: 0, amber: 0, red: 0, spreadM: 0 };
  return `<div class="spread-summary">
    <div class="spread-cell green"><b>● ${distribution.green}</b>GREEN</div>
    <div class="spread-cell amber"><b>▲ ${distribution.amber}</b>AMBER</div>
    <div class="spread-cell red"><b>■ ${distribution.red}</b>RED</div>
  </div>`;
}

function renderHostAlerts(room) {
  const alerts = (room.alerts || []).filter((alert) => ["open", "escalated"].includes(alert.state)).reverse();
  if (!alerts.length) return `<div class="banner success">열린 안전 알림이 없어요.</div>`;
  return alerts.map((alert) => `<div class="alert-card ${alert.level === "notice" ? "notice" : ""}">
    <div><strong>${alert.type.toUpperCase()} · ${escapeHtml(alert.name)}</strong><p class="sub" style="margin-top:4px;color:inherit">${escapeHtml(alert.text)} · ${timeAgo(alert.createdAt)}</p></div>
    <button class="mini-btn dark" onclick="ackAlert('${alert.id}')">확인했어요</button>
  </div>`).join("");
}

function setHostTab(tab) {
  state.hostTab = tab;
  renderHost(false);
}

function renderHost(preserve = true) {
  const room = state.room || {};
  if (room.viewerRole !== "host") return renderWatcher(preserve, "이 기기에는 호스트 권한이 없어요.");
  if (room.phase === "ended") return renderResult(preserve);
  const waiting = room.phase === "waiting";
  if (waiting) {
    setApp(`${statusBar(true)}
      <section class="screen dark-screen lobby-screen">
        <div class="topbar"><button class="icon-btn" onclick="goHome()" aria-label="홈으로">‹</button><span class="pill">HOST · LOBBY</span></div>
        <div class="stack">
          ${renderConnectionBanner()}
          <div class="lobby-head"><p class="report-kicker">ROOM ${escapeHtml(room.code || "")}</p><h2 class="title" style="margin-top:12px">크루가<br>모이고 있어요</h2><p class="sub" style="margin-top:8px">${escapeHtml(room.name || "PacePop Run")} · ${room.participants?.length || 0}/${room.memberLimit || 10}명</p></div>
          ${notificationPrompt()}
          <div class="panel">
            <div class="qr-wrap">
              <img class="qr" src="${attribute(room.qrUrl)}" alt="PacePop 입장 QR">
              <div class="stack"><span class="code">${escapeHtml(room.code)}</span><div class="copyline">${escapeHtml(room.joinUrl)}</div><div class="share-row"><button class="mini-btn lime" onclick="shareRoom()">QR 공유</button><button class="mini-btn" onclick="copyText('${attribute(room.joinUrl)}')">링크 복사</button></div></div>
            </div>
          </div>
          <div class="panel stack"><div class="phase-row" style="justify-content:space-between"><strong>JOINED RUNNERS</strong><span class="pill">${room.participants?.length || 0}</span></div><div class="people">${(room.participants || []).map((person) => personCard(person, true)).join("")}</div></div>
          <button class="cta" onclick="startRun()">START RUN</button>
          <button class="ghost" onclick="leaveRoom()">LEAVE ROOM</button>
        </div>
      </section>`, preserve);
    return;
  }

  const activeAlerts = (room.alerts || []).filter((alert) => ["open", "escalated"].includes(alert.state)).length;
  const liveBody = state.hostTab === "alerts"
    ? `<div class="stack"><div><h3 class="title" style="font-size:22px;color:#fff">SAFETY ALERTS</h3><p class="sub" style="color:#a9a99e;margin-top:6px">HELP는 60초 미확인 시 크루 전체에 확대돼요.</p></div>${renderHostAlerts(room)}</div>`
    : state.hostTab === "crew"
      ? `<div class="stack"><div><h3 class="title" style="font-size:22px;color:#fff">CREW ROSTER</h3><p class="sub" style="color:#a9a99e;margin-top:6px">호스트 이전·내보내기·KUDO를 관리해요.</p></div><div class="people">${(room.participants || []).map((person) => personCard(person, true)).join("")}</div></div>`
      : `<div class="stack">
          <div class="phase-row" style="justify-content:space-between"><div><h3 class="title" style="font-size:22px;color:#fff">CREW SPREAD</h3><p class="sub" style="color:#a9a99e;margin-top:6px">${room.distribution?.active ? `${room.distribution.spreadM}m 벌어짐` : "4명부터 SPREAD가 활성화돼요."}</p></div><span class="pill">LIVE</span></div>
          ${renderSpread(room)}
          <div class="stats"><div class="stat"><span>RUNNERS</span><b>${room.participants?.length || 0}</b></div><div class="stat"><span>ALERTS</span><b>${activeAlerts}</b></div><div class="stat"><span>TIME</span><b style="font-size:16px">${elapsed(room.startedAt)}</b></div><div class="stat"><span>SPREAD</span><b>${room.distribution?.spreadM || 0}m</b></div></div>
          <div class="stack"><div class="phase-row" style="justify-content:space-between"><strong>CREW CHAT</strong><span class="sub" style="color:#8c8c84">LIVE</span></div><div class="messages">${renderMessages(room, 5)}</div><div class="composer"><input id="chatInput" maxlength="500" placeholder="채팅 보내기" value="${attribute(state.chatText)}" oninput="rememberChat(this.value)" onkeydown="if(event.key==='Enter') sendTypedChat()"><button class="send" onclick="sendTypedChat()">↑</button></div></div>
          <button class="cta" onclick="finishRoom()">END RUN</button>
        </div>`;

  setApp(`${statusBar()}
    <section class="screen host-live-screen">
      <div class="topbar"><button class="icon-btn" onclick="goHome()" aria-label="홈으로">⌂</button><span class="pill">HOST · LIVE</span></div>
      ${renderConnectionBanner()}${notificationPrompt()}
      ${renderMap(room, room.meId)}
      <div class="live-sheet">
        <div class="sheet-handle"></div>
        <div class="live-tabs"><button class="${state.hostTab === "live" ? "active" : ""}" onclick="setHostTab('live')">MAP</button><button class="${state.hostTab === "alerts" ? "active" : ""}" onclick="setHostTab('alerts')">ALERTS ${activeAlerts ? `· ${activeAlerts}` : ""}</button><button class="${state.hostTab === "crew" ? "active" : ""}" onclick="setHostTab('crew')">ROSTER</button></div>
        ${liveBody}
      </div>
    </section>`, preserve);
}

function runnerSafetyBanner(room) {
  const urgent = (room.alerts || []).find((alert) => alert.state === "escalated" && alert.participantId !== room.meId);
  if (!urgent) return "";
  return `<div class="banner urgent">긴급: ${escapeHtml(urgent.name)}님의 HELP 요청을 확인해 주세요.</div>`;
}

function setRunnerTab(tab) {
  state.runnerTab = tab;
  renderRunner(false);
}

function renderRunnerNav() {
  return `<nav class="runner-nav" aria-label="러너 메뉴"><button class="${state.runnerTab === "run" ? "active" : ""}" onclick="setRunnerTab('run')">RUN</button><button class="${state.runnerTab === "chat" ? "active" : ""}" onclick="setRunnerTab('chat')">CHAT</button><button class="${state.runnerTab === "kudo" ? "active" : ""}" onclick="setRunnerTab('kudo')">KUDO</button></nav>`;
}

function renderRunner(preserve = true) {
  const room = state.room || {};
  if (room.viewerRole === "host") return renderHost(preserve);
  if (room.phase === "ended") return renderResult(preserve);
  const me = (room.participants || []).find((person) => person.id === room.meId) || {};
  const courseDistance = Number(room.course?.distanceKm || 0);
  const left = Math.max(0, courseDistance - Number(me.distance || 0));
  const waiting = room.phase === "waiting";
  const activeSignal = ["help", "water", "rest", "giveup"].includes(me.status) ? me.status : "";
  const badge = "RUNNER";

  if (state.runnerTab === "chat") {
    setApp(`${statusBar(true)}
      <section class="screen dark-screen runner-chat-screen">
        <div class="topbar"><button class="icon-btn" onclick="setRunnerTab('run')" aria-label="러닝 화면">‹</button><span class="pill">${badge}</span></div>
        ${renderConnectionBanner()}${runnerSafetyBanner(room)}
        <div class="stack"><div class="phase-row" style="justify-content:space-between"><div><h2 class="title" style="font-size:22px">CREW CHAT</h2><p class="sub" style="margin-top:6px">${room.participants?.length || 0}명 참여 중</p></div><button class="mini-btn lime" onclick="sendSignal('help','잠깐만요, 도움이 필요해요')">HELP</button></div><div class="chips">${["천천히!", "물 필요", "여기서 쉬자", "곧 도착"].map((text) => `<button class="chip" onclick="sendChat('${text}')">${text}</button>`).join("")}</div><div class="messages">${renderMessages(room, 30)}</div><div class="composer"><input id="chatInput" maxlength="500" placeholder="메시지 보내기" value="${attribute(state.chatText)}" oninput="rememberChat(this.value)" onkeydown="if(event.key==='Enter') sendTypedChat()"><button class="send" onclick="sendTypedChat()">↑</button></div><button class="ghost" onclick="leaveRoom()">LEAVE CREW</button></div>
        ${renderRunnerNav()}
      </section>`, preserve);
    return;
  }

  if (state.runnerTab === "kudo") {
    setApp(`${statusBar(true)}
      <section class="screen dark-screen runner-kudo-screen">
        <div class="topbar"><button class="icon-btn" onclick="setRunnerTab('run')" aria-label="러닝 화면">‹</button><span class="pill">${room.kudoRemaining || 0} LEFT</span></div>
        ${renderConnectionBanner()}
        <div class="stack"><div><p class="report-kicker">KUDO · ONE TAP</p><h2 class="title" style="margin-top:12px">오늘 함께 뛴<br>사람에게 별을 보내요</h2><p class="sub" style="margin-top:8px">한 사람에게 한 번 · 최대 3개</p></div><div class="people">${(room.participants || []).filter((person) => person.id !== room.meId).map((person) => personCard(person)).join("") || `<p class="sub">다른 러너가 들어오면 KUDO를 보낼 수 있어요.</p>`}</div></div>
        ${renderRunnerNav()}
      </section>`, preserve);
    return;
  }

  setApp(`${statusBar()}
    <section class="screen runner-live-screen">
      <div class="topbar"><button class="icon-btn" onclick="goHome()" aria-label="홈으로">⌂</button><span class="pill">${badge}</span></div>
      ${renderConnectionBanner()}${runnerSafetyBanner(room)}${renderMap(room, room.meId)}
      <div class="live-sheet">
        <div class="sheet-handle"></div>
        <div style="display:flex;justify-content:space-between;align-items:end;gap:14px;margin-bottom:16px"><div><p class="eyebrow" style="color:#8c8c84;letter-spacing:.18em">MY DISTANCE</p><h2 class="title" style="font-size:48px;color:#fff">${Number(me.distance || 0).toFixed(2)}<span style="font-size:16px;color:#8c8c84"> KM</span></h2></div><div style="text-align:right"><p class="eyebrow" style="color:#8c8c84;letter-spacing:.18em">ELAPSED</p><strong style="font:800 24px/1 'Archivo',sans-serif">${elapsed(room.startedAt || me.joinedAt)}</strong></div></div>
        ${waiting ? `<div class="banner" style="margin-bottom:14px">호스트가 러닝을 시작할 때까지 기다리는 중이에요.</div>` : ""}
        <div class="stats" style="margin-bottom:14px"><div class="stat"><span>PACE</span><b>${escapeHtml(me.pace || "--")}</b></div><div class="stat"><span>AVG</span><b>${escapeHtml(me.avgPace || "--")}</b></div><div class="stat"><span>CREW</span><b>${room.participants?.length || 0}</b></div><div class="stat"><span>LEFT</span><b>${left.toFixed(1)}</b></div></div>
        <div class="actions"><button class="action help" onclick="sendSignal('${activeSignal === "help" ? "ok" : "help"}','잠깐만요, 도움이 필요해요')">${icon("help")}${activeSignal === "help" ? "I'M OK" : "HELP"}</button><button class="action water" onclick="sendSignal('${activeSignal === "water" ? "ok" : "water"}','물 필요')">${icon("water")}${activeSignal === "water" ? "I'M OK" : "WATER"}</button><button class="action rest" onclick="sendSignal('${activeSignal === "rest" ? "ok" : "rest"}','여기서 쉬자')">${icon("rest")}${activeSignal === "rest" ? "I'M OK" : "REST"}</button><button class="action giveup" onclick="sendSignal('${activeSignal === "giveup" ? "ok" : "giveup"}','오늘은 여기까지')">${icon("giveup")}${activeSignal === "giveup" ? "RETURN" : "GIVE UP"}</button></div>
        ${renderRunnerNav()}
      </div>
    </section>`, preserve);
}

function renderWatcher(preserve = true, warning = "") {
  const room = state.room || {};
  setApp(`${statusBar(true)}
    <section class="screen watch-screen">
      <div class="topbar"><button class="icon-btn" onclick="goHome()" aria-label="홈으로">⌂</button><span class="pill">WATCH MODE</span></div>
      <div class="stack">
        ${warning ? `<div class="banner">${escapeHtml(warning)}</div>` : ""}
        <div><h2 class="title">${escapeHtml(room.name || "PacePop")}</h2><p class="sub">ROOM ${escapeHtml(room.code || "")} · 읽기 전용</p></div>
        ${renderConnectionBanner()}
        ${renderMap(room)}
        <div class="dark-panel"><h3 class="title" style="font-size:24px;color:#fff">Crew Spread</h3>${renderSpread(room)}</div>
        <div class="panel stack"><h3 class="title" style="font-size:24px">Runners</h3><div class="people">${(room.participants || []).map((person) => personCard({ ...person, role: "host" })).join("")}</div></div>
      </div>
    </section>`, preserve);
}

function resultCountdown(room) {
  const seconds = Math.max(0, Math.ceil((Number(room.purgeAt || Date.now()) - Date.now()) / 1000));
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
}

function renderGiftReceipt(receipt) {
  return `<div class="panel stack coupon-card">
    <div style="display:flex;align-items:center;gap:14px"><span class="pill">SENT</span><div><h3 class="title" style="font-size:24px">SODA Gift 발송 완료</h3><p class="sub">${escapeHtml(receipt.item)} · 이메일을 확인해 주세요.</p></div></div>
    <div class="gift-receipt"><span>ORDER ID</span><strong>${escapeHtml(receipt.orderId)}</strong><small>${new Date(receipt.issuedAt).toLocaleString("ko-KR")}</small></div>
  </div>`;
}

function renderResult(preserve = true) {
  const room = state.room || {};
  const me = (room.participants || []).find((person) => person.id === room.meId) || {};
  const winner = room.gift ? (room.participants || []).find((person) => person.id === room.gift.winnerId) : null;
  const iWon = Boolean(winner && winner.id === room.meId);
  const giftArea = iWon && room.gift?.state === "claimed" && room.receipt
    ? renderGiftReceipt(room.receipt)
    : iWon && ["ready", "failed"].includes(room.gift?.state)
      ? `<button class="cta" onclick="openGiftModal()">SODA Gift 고르고 이메일로 받기</button>${room.gift?.error ? `<div class="banner urgent">${escapeHtml(room.gift.error)}</div>` : ""}`
      : iWon && room.gift?.state === "issuing"
        ? `<div class="banner">SODA Gift를 발송하고 있어요…</div>`
        : room.gift
          ? `<div class="banner success">${escapeHtml(room.gift.winnerName)}님이 오늘의 MVP예요!</div>`
          : `<div class="banner success">오늘은 모두가 MVP예요!</div>`;
  setApp(`${statusBar(true)}
    <section class="screen result-screen coupon">
      <div class="topbar"><button class="icon-btn" onclick="goHome()" aria-label="홈으로">⌂</button><span class="pill">RESULT</span></div>
      <div class="stack">
        <div><p class="report-kicker">RUN CLOSED · ${room.viewerRole === "host" ? "HOST REPORT" : "RUNNER REPORT"}</p><h1 class="report-title">${room.viewerRole === "host" ? "EVERYONE<br>CAME BACK." : `${Number(me.distance || 0).toFixed(2)} KM<br>YOU HELD ON.`}</h1></div>
        <div class="result-hero">
          <div>
            <div class="crown">${winner ? "♛" : "★"}</div>
            <img class="winner-avatar" src="${attribute(winner?.avatar || "/assets/av/1.png")}" alt="">
            <p class="eyebrow" style="margin-top:16px;color:rgba(0,0,0,.56)">${winner ? "KUDO WINNER" : "PACEPOP CREW"}</p>
            <h2 class="title" style="font-size:34px;margin-top:6px">${winner ? escapeHtml(winner.name) : "모두가 MVP"}</h2>
            <p class="sub" style="color:rgba(0,0,0,.58);margin-top:7px">${winner ? `KUDO ${winner.kudos || 0}개로 선정됐어요.` : "오늘의 러닝을 함께 완성했어요."}</p>
          </div>
        </div>
        <div class="dark-panel">
          <div class="stats">
            <div class="stat"><span>DISTANCE</span><b>${Number(me.distance || 0).toFixed(2)}</b></div>
            <div class="stat"><span>TIME</span><b style="font-size:18px">${elapsed(room.startedAt, room.finishedAt)}</b></div>
            <div class="stat"><span>AVG</span><b>${escapeHtml(me.avgPace || "--")}</b></div>
            <div class="stat"><span>KUDO</span><b>${me.kudos || 0}</b></div>
          </div>
        </div>
        ${giftArea}
        ${room.meId ? `<div class="panel stack"><div><h3 class="title" style="font-size:24px">내 기록 받기</h3><p class="sub">${resultCountdown(room)} 뒤 임시 위치와 채팅이 자동 삭제돼요.</p></div><div class="download-grid"><button class="mini-btn" onclick="downloadExport('gpx')">GPX</button><button class="mini-btn" onclick="downloadExport('json')">요약 JSON</button><button class="mini-btn" onclick="downloadExport('chat')">채팅 TXT</button></div></div>` : ""}
        <button class="ghost" onclick="goHome()">홈으로 돌아가기</button>
      </div>
    </section>`, preserve);
}

async function loadRoom(code, mode) {
  state.roomCode = String(code || "").toUpperCase();
  state.fixQueue = readFixQueue(state.roomCode);
  state.mode = mode;
  state.participantToken = readToken(state.roomCode);
  try {
    const room = await api(`/api/rooms/${state.roomCode}`, { token: mode === "watcher" ? "" : state.participantToken });
    state.room = room;
    state.participantId = room.meId || "";
    if (mode === "join" && state.participantToken && room.meId) {
      const me = room.participants.find((person) => person.id === room.meId);
      state.pendingJoin = { code: room.code, name: me?.name || state.participantName || "Runner" };
      await completeJoin(null);
      return;
    }
    if (mode === "host" && room.viewerRole === "host") {
      renderHost(false);
      startHeartbeat();
    } else if (mode === "watcher" || (mode === "host" && room.viewerRole !== "host")) {
      renderWatcher(false, mode === "host" ? "호스트 링크는 이 방을 만든 기기에서 열어 주세요." : "");
    } else if (mode === "coupon" && room.phase === "ended") {
      renderResult(false);
    } else {
      renderJoin(false);
    }
    startPolling();
    if (room.meId) {
      startLocation();
      startHeartbeat();
    }
  } catch (error) {
    state.room = null;
    showToast(error.message, 2800);
    if (mode === "join") renderJoin(false);
    else renderHome();
  }
}

function renderCurrent(preserve = true) {
  if (!state.room) return;
  if (state.room.phase === "ended") return renderResult(preserve);
  if (state.mode === "watcher") return renderWatcher(preserve);
  if (state.room.viewerRole === "host") return renderHost(preserve);
  if (state.room.meId) return renderRunner(preserve);
  return renderWatcher(preserve);
}

async function pollRoom() {
  if (!state.roomCode || state.mode === "home" || state.mode === "join" && !state.room?.meId) return;
  try {
    const room = await api(`/api/rooms/${state.roomCode}`, { token: state.mode === "watcher" ? "" : state.participantToken, timeout: 8000 });
    const wasEnded = state.room?.phase === "ended";
    state.room = room;
    state.participantId = room.meId || state.participantId;
    state.connected = true;
    state.pollDelay = 1400;
    announceUrgentAlerts(room);
    renderCurrent(true);
    if (!wasEnded && room.phase === "ended") stopLocation();
  } catch (error) {
    state.connected = false;
    state.pollDelay = Math.min(30_000, Math.max(2000, state.pollDelay * 1.8));
    if ([404, 410].includes(error.status)) {
      stopRealtime();
      showToast(error.message, 3000);
      return;
    }
  } finally {
    clearTimeout(state.pollTimer);
    if (state.roomCode && !["home", "create", "join"].includes(state.mode)) {
      state.pollTimer = setTimeout(pollRoom, state.pollDelay + Math.random() * 240);
    }
  }
}

function startPolling() {
  clearTimeout(state.pollTimer);
  state.pollDelay = 1400;
  state.pollTimer = setTimeout(pollRoom, 700);
}

function stopRealtime() {
  clearTimeout(state.pollTimer);
  clearInterval(state.heartbeatTimer);
  state.pollTimer = null;
  state.heartbeatTimer = null;
  stopLocation();
  state.wakeLock?.release?.().catch(() => {});
  state.wakeLock = null;
}

function startHeartbeat() {
  clearInterval(state.heartbeatTimer);
  if (!state.participantToken || !state.roomCode) return;
  state.heartbeatTimer = setInterval(heartbeat, 3000);
}

function startLocation() {
  if (state.watchId !== null || !("geolocation" in navigator) || !window.isSecureContext) return;
  state.watchId = navigator.geolocation.watchPosition(
    (position) => {
      state.latestFix = {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: position.timestamp,
      };
      state.fixQueue.push(state.latestFix);
      state.fixQueue = state.fixQueue.slice(-300);
      try { localStorage.setItem(fixQueueKey(state.roomCode), JSON.stringify(state.fixQueue)); } catch {}
    },
    (error) => {
      if (error.code === 1) showToast("위치 권한이 꺼졌어요. 지도는 마지막 위치를 유지합니다.", 2600);
    },
    { enableHighAccuracy: true, maximumAge: 3000, timeout: 20_000 },
  );
}

function stopLocation() {
  if (state.watchId !== null && "geolocation" in navigator) navigator.geolocation.clearWatch(state.watchId);
  state.watchId = null;
}

async function heartbeat() {
  if (!state.roomCode || !state.participantToken || state.room?.phase === "ended") return;
  state.seq += 1;
  try { localStorage.setItem("pacepop.seq", String(state.seq)); } catch {}
  const fixes = state.fixQueue.slice(-100);
  const latest = state.latestFix || fixes.at(-1);
  try {
    state.room = await api(`/api/rooms/${state.roomCode}/heartbeat`, {
      method: "POST",
      body: {
        participantToken: state.participantToken,
        seq: state.seq,
        ...(latest || {}),
        fixes,
      },
      timeout: 8000,
    });
    state.fixQueue = [];
    try { localStorage.removeItem(fixQueueKey(state.roomCode)); } catch {}
    state.connected = true;
    renderCurrent(true);
  } catch {
    state.connected = false;
  }
}

async function startRun() {
  ensureAudio();
  try {
    try {
      state.latestFix = await requestInitialPosition();
      startLocation();
    } catch (error) {
      showToast(`${error.message} 러닝은 시작하지만 GPS 상태를 확인해 주세요.`, 3000);
    }
    state.room = await api(`/api/rooms/${state.roomCode}/start`, { method: "POST", body: { participantToken: state.participantToken } });
    renderHost(false);
    requestWakeLock();
    heartbeat();
  } catch (error) {
    showToast(error.message, 2600);
  }
}

async function sendSignal(type, text) {
  ensureAudio();
  if (type === "giveup" && !confirm("러닝을 그만두는 상태로 바꿀까요? 위치와 채팅은 계속 유지됩니다.")) return;
  try {
    state.room = await api(`/api/rooms/${state.roomCode}/signal`, { method: "POST", body: { participantToken: state.participantToken, type, text } });
    showToast(type === "ok" ? "상태를 정상으로 바꿨어요." : `${type.toUpperCase()} 보냄`);
    renderCurrent(true);
  } catch (error) { showToast(error.message, 2600); }
}

function rememberChat(value) {
  state.chatText = String(value || "").slice(0, 500);
}

async function sendChat(text) {
  const message = String(text || "").trim();
  if (!message) return;
  try {
    state.room = await api(`/api/rooms/${state.roomCode}/chat`, { method: "POST", body: { participantToken: state.participantToken, text: message } });
    state.chatText = "";
    renderCurrent(true);
  } catch (error) { showToast(error.message, 2600); }
}

function sendTypedChat() {
  const input = document.getElementById("chatInput");
  sendChat(input?.value || state.chatText);
}

async function sendKudo(toParticipantId) {
  ensureAudio();
  try {
    state.room = await api(`/api/rooms/${state.roomCode}/kudo`, { method: "POST", body: { participantToken: state.participantToken, toParticipantId } });
    showToast("KUDO 보냄 ★");
    renderCurrent(true);
  } catch (error) { showToast(error.message, 2600); }
}

async function ackAlert(alertId) {
  try {
    state.room = await api(`/api/rooms/${state.roomCode}/ack`, { method: "POST", body: { participantToken: state.participantToken, alertId } });
    showToast("안전 알림을 확인했어요.");
    renderHost(true);
  } catch (error) { showToast(error.message, 2600); }
}

async function transferHost(toParticipantId) {
  if (!confirm("이 러너에게 호스트 권한을 넘길까요?")) return;
  try {
    state.room = await api(`/api/rooms/${state.roomCode}/transfer`, { method: "POST", body: { participantToken: state.participantToken, toParticipantId } });
    showToast("호스트 권한을 넘겼어요.");
    state.mode = "runner";
    history.replaceState(null, "", `/j/${state.roomCode}`);
    renderRunner(false);
  } catch (error) { showToast(error.message, 2600); }
}

async function kickRunner(toParticipantId) {
  if (!confirm("이 러너를 방에서 내보낼까요?")) return;
  try {
    state.room = await api(`/api/rooms/${state.roomCode}/kick`, { method: "POST", body: { participantToken: state.participantToken, toParticipantId } });
    showToast("러너를 내보냈어요.");
    renderHost(true);
  } catch (error) { showToast(error.message, 2600); }
}

async function finishRoom() {
  if (!confirm(`${state.room?.participants?.length || 0}명의 러닝을 종료하고 KUDO MVP를 정할까요?`)) return;
  try {
    state.room = await api(`/api/rooms/${state.roomCode}/finish`, { method: "POST", body: { participantToken: state.participantToken } });
    stopLocation();
    renderResult(false);
  } catch (error) { showToast(error.message, 2600); }
}

async function leaveRoom() {
  if (!confirm("이 크루에서 나갈까요?")) return;
  try {
    await api(`/api/rooms/${state.roomCode}/leave`, { method: "POST", body: { participantToken: state.participantToken } });
    localStorage.removeItem(tokenKey(state.roomCode));
    goHome();
  } catch (error) { showToast(error.message, 2600); }
}

function closeModal() {
  if (activeQrScanner) {
    activeQrScanner.stop?.();
    activeQrScanner.destroy?.();
    activeQrScanner = null;
  }
  document.getElementById("modal")?.remove();
}

async function openGiftModal() {
  closeModal();
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.id = "modal";
  overlay.innerHTML = `<div class="modal-card gift-modal stack"><div><p class="report-kicker">SODA GIFT · KUDO MVP REWARD</p><h2 class="title" style="font-size:28px;margin-top:12px">기프트를 고르는 중…</h2></div></div>`;
  document.body.appendChild(overlay);
  try {
    state.giftCatalog = await api("/api/soda/catalog", { token: "" });
    state.selectedGiftId = null;
    renderGiftModal();
  } catch (error) {
    overlay.innerHTML = `<div class="modal-card gift-modal stack"><h2 class="title" style="font-size:28px">카탈로그 오류</h2><div class="banner urgent">${escapeHtml(error.message)}</div><button class="ghost" onclick="closeModal()">닫기</button></div>`;
  }
}

function renderGiftModal(status = "") {
  const overlay = document.getElementById("modal");
  if (!overlay) return;
  const catalog = state.giftCatalog || { products: [] };
  overlay.innerHTML = `<div class="modal-card gift-modal stack" role="dialog" aria-modal="true" aria-label="SODA Gift 선택">
    <div class="phase-row" style="justify-content:space-between"><div><p class="report-kicker">SODA GIFT · KUDO MVP REWARD</p><h2 class="title" style="font-size:28px;margin-top:10px">MVP의 선물을<br>골라주세요</h2><p class="sub" style="margin-top:7px">${catalog.live ? `SodaGift ${catalog.sandbox ? "Sandbox" : "Live"}` : "API 설정 필요"}</p></div><button class="icon-btn" onclick="closeModal()" aria-label="닫기">×</button></div>
    ${catalog.message ? `<div class="banner">${escapeHtml(catalog.message)}</div>` : ""}
    <div class="gift-grid">${(catalog.products || []).map((product) => `<button class="gift-item ${String(product.id) === String(state.selectedGiftId) ? "selected" : ""}" onclick="selectGift('${attribute(product.id)}')">${product.image_url ? `<img src="${attribute(product.image_url)}" alt="" onerror="this.style.display='none'">` : ""}<strong>${escapeHtml(product.brand || product.name)}</strong><span>${escapeHtml(product.name)} · ${product.amount ?? product.min_amount ?? ""} ${escapeHtml(product.currency || "")}</span></button>`).join("") || `<div class="banner urgent" style="grid-column:1/-1">주문 가능한 기프트가 없어요. Vercel 환경변수를 확인해 주세요.</div>`}</div>
    <label class="field-label">받을 이메일<input id="giftEmail" type="email" autocomplete="email" placeholder="you@example.com"></label>
    ${status ? `<div class="banner ${status.startsWith("❌") ? "urgent" : ""}">${escapeHtml(status)}</div>` : ""}
    <button class="cta" onclick="claimGift()" ${(catalog.products || []).length ? "" : "disabled"}>이메일로 받기</button>
    <p class="sub">버튼을 누르면 선택한 이메일로 실제 발송 요청이 전송됩니다. Sandbox 키에서는 테스트 주문만 생성됩니다.</p>
  </div>`;
}

function selectGift(productId) {
  state.selectedGiftId = productId;
  const email = document.getElementById("giftEmail")?.value || "";
  renderGiftModal();
  const input = document.getElementById("giftEmail");
  if (input) input.value = email;
}

async function claimGift() {
  const email = document.getElementById("giftEmail")?.value.trim() || "";
  if (!state.selectedGiftId) return renderGiftModal("❌ 기프트를 먼저 선택해 주세요.");
  if (!email.includes("@")) return renderGiftModal("❌ 이메일을 확인해 주세요.");
  const button = document.activeElement?.tagName === "BUTTON" ? document.activeElement : null;
  if (button) {
    button.disabled = true;
    button.textContent = "발송 중…";
  }
  try {
    await api(`/api/rooms/${state.roomCode}/gift/claim`, {
      method: "POST",
      body: { participantToken: state.participantToken, productId: state.selectedGiftId, email },
      timeout: 18_000,
    });
    closeModal();
    state.room = await api(`/api/rooms/${state.roomCode}`);
    showToast("발송 완료! 이메일을 확인해 주세요.", 3000);
    renderResult(false);
  } catch (error) {
    renderGiftModal(`❌ ${error.message}`);
    const input = document.getElementById("giftEmail");
    if (input) input.value = email;
  }
}

async function downloadExport(format) {
  try {
    const response = await fetch(`/api/rooms/${state.roomCode}/export?format=${encodeURIComponent(format)}`, { headers: { Authorization: `Bearer ${state.participantToken}` } });
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.message || "다운로드하지 못했어요.");
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    const disposition = response.headers.get("Content-Disposition") || "";
    anchor.download = disposition.match(/filename="([^"]+)"/)?.[1] || `pacepop-${format}`;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  } catch (error) { showToast(error.message, 2600); }
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const input = document.createElement("textarea");
    input.value = text;
    document.body.appendChild(input);
    input.select();
    document.execCommand("copy");
    input.remove();
  }
  showToast("복사했어요.");
}

async function shareRoom() {
  const data = { title: "PacePop", text: `${state.room?.name || "PacePop"} 크루에 합류하세요`, url: state.room?.joinUrl };
  if (navigator.share) {
    try { await navigator.share(data); return; } catch {}
  }
  copyText(data.url || "");
}

function ensureAudio() {
  try {
    state.audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    state.audioContext.resume?.();
  } catch {}
}

function urgentFeedback() {
  try { navigator.vibrate?.([180, 100, 180]); } catch {}
  try {
    ensureAudio();
    const oscillator = state.audioContext.createOscillator();
    const gain = state.audioContext.createGain();
    oscillator.frequency.value = 660;
    gain.gain.setValueAtTime(.05, state.audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001, state.audioContext.currentTime + .28);
    oscillator.connect(gain).connect(state.audioContext.destination);
    oscillator.start();
    oscillator.stop(state.audioContext.currentTime + .3);
  } catch {}
}

function announceUrgentAlerts(room) {
  for (const alert of room.alerts || []) {
    if (!["open", "escalated"].includes(alert.state) || alert.level !== "urgent" || state.seenAlerts.has(alert.id)) continue;
    state.seenAlerts.add(alert.id);
    urgentFeedback();
    showToast(`${alert.name}: ${alert.text}`, 4200);
    if ("Notification" in window && Notification.permission === "granted") {
      const title = `PacePop HELP · ${alert.name}`;
      const options = { body: alert.text, tag: `pacepop-help-${alert.id}`, icon: "/assets/av/1.png", data: { url: `/host/${room.code}` }, renotify: true };
      if (navigator.serviceWorker?.ready) navigator.serviceWorker.ready.then((registration) => registration.showNotification(title, options)).catch(() => {});
      else try { new Notification(title, options); } catch {}
    }
  }
}

async function requestWakeLock() {
  if (!("wakeLock" in navigator) || document.visibilityState !== "visible") return;
  try { state.wakeLock = await navigator.wakeLock.request("screen"); } catch {}
}

function goHome() {
  stopRealtime();
  state.roomCode = "";
  state.participantToken = "";
  state.participantId = "";
  state.fixQueue = [];
  state.latestFix = null;
  state.mode = "home";
  state.hostTab = "live";
  state.runnerTab = "run";
  history.replaceState(null, "", "/");
  renderHome();
}

function boot() {
  try { localStorage.removeItem("pacepop.fixQueue"); } catch {}
  const path = location.pathname;
  const host = path.match(/^\/host\/([A-Za-z0-9]+)/);
  const join = path.match(/^\/j\/([A-Za-z0-9]+)/);
  const watcher = path.match(/^\/w\/([A-Za-z0-9]+)/);
  const coupon = path.match(/^\/coupon\/([A-Za-z0-9]+)/);
  if (host) return loadRoom(host[1], "host");
  if (join) {
    state.roomCode = join[1].toUpperCase();
    return loadRoom(state.roomCode, "join");
  }
  if (watcher) return loadRoom(watcher[1], "watcher");
  if (coupon) return loadRoom(coupon[1], "coupon");
  renderHome();
}

Object.assign(window, {
  openHostCreate,
  updateCourseDraft,
  searchCoursePlace,
  pickCoursePlace,
  useCurrentCourseStart,
  setTargetPace,
  setMeetAt,
  changeMemberLimit,
  createHostRoom,
  openRunnerJoin,
  openQrScanner,
  scanQrFile,
  joinRoom,
  retryLocationJoin,
  enableSafetyNotifications,
  closeModal,
  startRun,
  sendSignal,
  rememberChat,
  sendChat,
  sendTypedChat,
  sendKudo,
  ackAlert,
  transferHost,
  kickRunner,
  finishRoom,
  leaveRoom,
  openGiftModal,
  selectGift,
  claimGift,
  downloadExport,
  copyText,
  shareRoom,
  setHostTab,
  setRunnerTab,
  goHome,
});

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible" && state.room?.phase === "running") requestWakeLock();
});
window.addEventListener("online", () => { state.connected = true; pollRoom(); heartbeat(); });
window.addEventListener("offline", () => { state.connected = false; renderCurrent(true); });
window.addEventListener("popstate", boot);
if ("serviceWorker" in navigator && location.protocol !== "file:") navigator.serviceWorker.register("/sw.js").catch(() => {});

boot();
