import test from "node:test";
import assert from "node:assert/strict";
import { completeGift, createRoom, getRoom, joinRoom, reserveGift, roomAction } from "../lib/rooms.mjs";

const origin = "http://pacepop.test";
const course = {
  start: { lat: 34, lng: -118, label: "Start" },
  destination: { lat: 34.009, lng: -118, label: "Finish" },
  distanceKm: 1.001,
  routingDurationMin: 12,
  coordinates: [[34, -118], [34.003, -118], [34.006, -118], [34.009, -118]],
  targetPace: "6:00",
  meetAt: "09:30",
  provider: "OpenStreetMap · Valhalla",
};

function roomInput(overrides = {}) {
  return { hostName: "Host", name: "Real Course", memberLimit: 6, course, ...overrides };
}

test("room lifecycle preserves membership, KUDO rules, and MVP result", async () => {
  const created = await createRoom(roomInput(), origin);
  assert.equal(created.phase, "waiting");
  assert.equal(created.course.distanceKm, course.distanceKm);
  assert.equal(created.memberLimit, 6);
  assert.equal(created.participants.length, 1);
  assert.match(created.joinUrl, new RegExp(`/j/${created.code}$`));

  const alex = await joinRoom(created.code, { name: "Alex" }, origin);
  const jordan = await joinRoom(created.code, { name: "Jordan" }, origin);
  assert.equal(jordan.participants.length, 3);

  const rejoined = await joinRoom(
    created.code,
    { name: "Alex", participantToken: alex.participantToken },
    origin,
  );
  assert.equal(rejoined.participant.id, alex.participant.id);
  assert.equal(rejoined.participants.length, 3);

  const started = await roomAction(
    created.code,
    "start",
    { participantToken: created.participantToken },
    origin,
  );
  assert.equal(started.phase, "running");

  await roomAction(
    created.code,
    "kudo",
    { participantToken: created.participantToken, toParticipantId: alex.participant.id },
    origin,
  );
  await roomAction(
    created.code,
    "kudo",
    { participantToken: jordan.participantToken, toParticipantId: alex.participant.id },
    origin,
  );
  await assert.rejects(
    roomAction(
      created.code,
      "kudo",
      { participantToken: jordan.participantToken, toParticipantId: alex.participant.id },
      origin,
    ),
    (error) => error.code === "duplicate_kudo",
  );

  const ended = await roomAction(
    created.code,
    "finish",
    { participantToken: created.participantToken },
    origin,
  );
  assert.equal(ended.phase, "ended");
  assert.equal(ended.gift.winnerId, alex.participant.id);

  const winnerView = await getRoom(created.code, origin, alex.participantToken);
  const otherView = await getRoom(created.code, origin, jordan.participantToken);
  assert.equal(winnerView.gift.canClaim, true);
  assert.equal(otherView.gift.canClaim, false);

  const reservation = await reserveGift(created.code, alex.participantToken, {
    email: "alex@example.com",
    product: { id: 1, name: "Coffee", brand: "Coffee", amount: 10, currency: "USD" },
  });
  await completeGift(created.code, reservation.requestId, { orderId: "sandbox-order-123" });
  assert.equal((await getRoom(created.code, origin, alex.participantToken)).receipt.orderId, "sandbox-order-123");
  assert.equal((await getRoom(created.code, origin, jordan.participantToken)).receipt, null);
  assert.equal((await getRoom(created.code, origin, "")).receipt, null);
});

test("host-only actions reject runner tokens", async () => {
  const created = await createRoom(roomInput(), origin);
  const runner = await joinRoom(created.code, { name: "Runner" }, origin);
  await assert.rejects(
    roomAction(created.code, "start", { participantToken: runner.participantToken }, origin),
    (error) => error.code === "host_only",
  );
});

test("room creation requires a calculated route", async () => {
  await assert.rejects(
    createRoom({ hostName: "Host" }, origin),
    (error) => error.code === "invalid_course",
  );
});

test("real GPS updates distance and hides exact coordinates from watchers", async () => {
  const created = await createRoom(roomInput(), origin);
  const runner = await joinRoom(created.code, { name: "GPS Runner" }, origin);
  await roomAction(created.code, "start", { participantToken: created.participantToken }, origin);
  const timestamp = Date.now();
  const updated = await roomAction(created.code, "heartbeat", {
    participantToken: runner.participantToken,
    seq: 1,
    fixes: [
      { lat: 34, lng: -118, accuracy: 5, timestamp: timestamp - 20_000 },
      { lat: 34.0003, lng: -118, accuracy: 5, timestamp: timestamp - 10_000 },
      { lat: 34.0006, lng: -118, accuracy: 5, timestamp },
    ],
  }, origin);
  const mine = updated.participants.find((person) => person.id === runner.participant.id);
  assert.ok(mine.distance > 0.05);
  assert.notEqual(mine.pace, "--");
  assert.notEqual(mine.avgPace, "--");
  assert.equal(mine.lat, 34.0006);

  const watcher = await getRoom(created.code, origin, "");
  const hidden = watcher.participants.find((person) => person.id === runner.participant.id);
  assert.equal(hidden.lat, null);
  assert.equal(hidden.lng, null);
  assert.deepEqual(watcher.messages, []);
  assert.deepEqual(watcher.alerts, []);

  const member = await getRoom(created.code, origin, created.participantToken);
  assert.equal(member.participants.find((person) => person.id === runner.participant.id).lat, 34.0006);
});

test("a room closes when its only host leaves", async () => {
  const created = await createRoom(roomInput(), origin);
  const ended = await roomAction(created.code, "leave", { participantToken: created.participantToken }, origin);
  assert.equal(ended.phase, "ended");
  await assert.rejects(
    joinRoom(created.code, { name: "Late Runner" }, origin),
    (error) => error.code === "room_ended",
  );
});
