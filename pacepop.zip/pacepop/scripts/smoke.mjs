const base = process.env.PACEPOP_TEST_URL || "http://127.0.0.1:4173";

async function request(path, { method = "GET", token = "", body } = {}) {
  const response = await fetch(`${base}${path}`, {
    method,
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(body ? { "Content-Type": "application/json" } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const type = response.headers.get("content-type") || "";
  const data = type.includes("json") ? await response.json() : await response.text();
  if (!response.ok) throw new Error(`${method} ${path}: ${response.status} ${JSON.stringify(data)}`);
  return { response, data };
}

const course = {
  start: { lat: 34, lng: -118, label: "Smoke Start" },
  destination: { lat: 34.009, lng: -118, label: "Smoke Finish" },
  distanceKm: 1.001,
  routingDurationMin: 12,
  coordinates: [[34, -118], [34.003, -118], [34.006, -118], [34.009, -118]],
  targetPace: "6:00",
  meetAt: "09:30",
  provider: "OpenStreetMap · Valhalla",
};
const created = (await request("/api/rooms", { method: "POST", body: { hostName: "Smoke Host", name: "Smoke Route", memberLimit: 6, course } })).data;
const hostToken = created.participantToken;
const first = (await request(`/api/rooms/${created.code}/join`, { method: "POST", body: { name: "Alex" } })).data;
const second = (await request(`/api/rooms/${created.code}/join`, { method: "POST", body: { name: "Jordan" } })).data;

await request(`/api/rooms/${created.code}/start`, { method: "POST", token: hostToken, body: { participantToken: hostToken } });
await request(`/api/rooms/${created.code}/heartbeat`, {
  method: "POST",
  token: first.participantToken,
  body: {
    participantToken: first.participantToken,
    seq: 1,
    fixes: [
      { lat: 34, lng: -118, accuracy: 5, timestamp: Date.now() - 20_000 },
      { lat: 34.0003, lng: -118, accuracy: 5, timestamp: Date.now() - 10_000 },
      { lat: 34.0006, lng: -118, accuracy: 5, timestamp: Date.now() },
    ],
  },
});
await request(`/api/rooms/${created.code}/chat`, {
  method: "POST",
  token: second.participantToken,
  body: { participantToken: second.participantToken, text: "곧 도착" },
});
const signaled = (await request(`/api/rooms/${created.code}/signal`, {
  method: "POST",
  token: first.participantToken,
  body: { participantToken: first.participantToken, type: "help", text: "테스트 HELP" },
})).data;
const alert = signaled.alerts.find((item) => item.participantId === first.participant.id && item.state === "open");
if (!alert) throw new Error("HELP alert was not created");
await request(`/api/rooms/${created.code}/ack`, {
  method: "POST",
  token: hostToken,
  body: { participantToken: hostToken, alertId: alert.id },
});

await request(`/api/rooms/${created.code}/kudo`, {
  method: "POST",
  token: hostToken,
  body: { participantToken: hostToken, toParticipantId: first.participant.id },
});
await request(`/api/rooms/${created.code}/kudo`, {
  method: "POST",
  token: second.participantToken,
  body: { participantToken: second.participantToken, toParticipantId: first.participant.id },
});

const ended = (await request(`/api/rooms/${created.code}/finish`, {
  method: "POST",
  token: hostToken,
  body: { participantToken: hostToken },
})).data;
if (ended.gift?.winnerId !== first.participant.id) throw new Error("KUDO winner was not selected");

const catalog = (await request("/api/soda/catalog")).data;
if (!catalog.products?.length) throw new Error("SodaGift catalog is empty");
let giftState = "ready";
if (process.env.PACEPOP_SMOKE_GIFT === "true") {
  const smokeEmail = process.env.PACEPOP_SMOKE_EMAIL;
  if (!smokeEmail) throw new Error("PACEPOP_SMOKE_EMAIL is required when PACEPOP_SMOKE_GIFT=true");
  const claim = (await request(`/api/rooms/${created.code}/gift/claim`, {
    method: "POST",
    token: first.participantToken,
    body: {
      participantToken: first.participantToken,
      productId: catalog.products[0].id,
      email: smokeEmail,
    },
  })).data;
  if (!claim.ok || claim.gift?.state !== "claimed") throw new Error("Gift claim did not complete");
  giftState = claim.gift.state;
}

const exported = await request(`/api/rooms/${created.code}/export?format=json`, { token: first.participantToken });
if (exported.data?.room !== created.code) throw new Error("Result export is invalid");
const qr = await request(`/api/qr/${created.code}`);
if (!String(qr.data).includes("<svg")) throw new Error("QR response is invalid");

console.log(JSON.stringify({
  ok: true,
  room: created.code,
  winner: ended.gift.winnerName,
  giftState,
  sodaSandbox: catalog.sandbox,
}));
