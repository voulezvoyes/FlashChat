import { access, copyFile, mkdir, readFile } from "node:fs/promises";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const exec = promisify(execFile);

await mkdir("public/vendor", { recursive: true });
await Promise.all([
  copyFile("node_modules/leaflet/dist/leaflet.css", "public/vendor/leaflet.css"),
  copyFile("node_modules/leaflet/dist/leaflet.js", "public/vendor/leaflet.js"),
  copyFile("node_modules/qr-scanner/qr-scanner.min.js", "public/vendor/qr-scanner.min.js"),
  copyFile("node_modules/qr-scanner/qr-scanner-worker.min.js", "public/vendor/qr-scanner-worker.min.js"),
]);

const required = [
  "public/index.html",
  "public/manifest.webmanifest",
  "public/sw.js",
  "public/app.js",
  "public/dc-theme.css",
  "public/vendor/leaflet.js",
  "public/vendor/qr-scanner.min.js",
  "api/router.js",
  "lib/rooms.mjs",
  "lib/routes.mjs",
  "lib/soda.mjs",
  "lib/store.mjs",
];

await Promise.all(required.map((file) => access(file)));
const html = await readFile("public/index.html", "utf8");
if (!html.includes("PacePop") || !html.includes('src="/app.js"') || !html.includes("/vendor/leaflet.js")) {
  throw new Error("PacePop client entry is incomplete.");
}
await Promise.all([
  exec(process.execPath, ["--check", "public/app.js"]),
  exec(process.execPath, ["--check", "public/sw.js"]),
  exec(process.execPath, ["--check", "api/router.js"]),
  exec(process.execPath, ["--check", "lib/rooms.mjs"]),
  exec(process.execPath, ["--check", "lib/routes.mjs"]),
  exec(process.execPath, ["--check", "lib/soda.mjs"]),
  exec(process.execPath, ["--check", "lib/store.mjs"]),
]);
console.log("PacePop static site and Vercel functions are ready.");
