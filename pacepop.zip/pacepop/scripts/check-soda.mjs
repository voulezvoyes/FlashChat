import { readFile } from "node:fs/promises";

const envPath = process.argv[2];
if (!envPath) throw new Error("Pass a .env file path.");
const text = await readFile(envPath, "utf8");
for (const line of text.split(/\r?\n/)) {
  const match = line.match(/^\s*(SODAGIFT_API_KEY|SODA_API_KEY)\s*=\s*(.*?)\s*$/);
  if (!match) continue;
  const value = match[2].replace(/^(['"])(.*)\1$/, "$2");
  process.env.SODAGIFT_API_KEY = value;
}
if (!process.env.SODAGIFT_API_KEY) throw new Error("No SodaGift API key found.");
const { giftCatalog } = await import(`../lib/soda.mjs?check=${Date.now()}`);
const catalog = await giftCatalog();
console.log(JSON.stringify({ live: catalog.live, sandbox: catalog.sandbox, products: catalog.products.length }));
